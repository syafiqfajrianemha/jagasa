package com.emha.jagasa.ui.Model

data class Animal(
    val id: Long,
    val name: String,
    val description: String,
    val photo: Int,
    val populasi: String
)